public class Key{
	private long key;
	
	public Key(long k){
		key = k;
	}
	
	public long getKey(){
		return key;
	}
}