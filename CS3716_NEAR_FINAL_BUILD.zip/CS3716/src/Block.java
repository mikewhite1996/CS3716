public interface Block {

public String getBlock();
public String toString();
public boolean equals(Block other);
}
