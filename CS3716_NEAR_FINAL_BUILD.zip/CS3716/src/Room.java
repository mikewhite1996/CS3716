public abstract class Room {

  public abstract String getName();
  public abstract int getCapacity();
  public abstract String toString();
}
